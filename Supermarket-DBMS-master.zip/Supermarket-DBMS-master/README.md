Supermarket Database Management System

PROJECT OBJECTIVE:

To regulate the functioning of supermarket.

PROJECT DESCRIPTION:

The “Supermarket Database Management System” is
a Database based on the sales transaction of items in
a supermarket. It manages the sales activity done in
a supermarket. It maintains the stock details, records of the sales,
customer details, return policies and also works on feedback. 
It also manages the employees associated.

Assumption:

(1) No replacement policy.

(2) Feedback is for the products purchased.
